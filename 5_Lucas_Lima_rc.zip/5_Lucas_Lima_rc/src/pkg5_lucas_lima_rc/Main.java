package pkg5_lucas_lima_rc;

import java.io.DataInputStream;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        float salarioBruto = 0.0f, inss = 0.0f, sindicato = 0.0f, ir = 0.0f,salarioLiquido = 0.0f;
        float descontos = 0.0f;
        DataInputStream dado = new DataInputStream (System.in);
        
        System.out.println("Informe seu salário bruto: ");
        salarioBruto = Float.parseFloat(dado.readLine());
        
        ir = salarioBruto * 0.11f;
        inss = salarioBruto * 0.08f;
        sindicato = salarioBruto * 0.05f;
        
        descontos = ir + inss + sindicato;
        salarioLiquido = salarioBruto - descontos;
        
        System.out.println("Seu IR vai custa: " + ir + "R$"
                + "\nSeu INSS vai custa: " + inss + "R$"
                + "\nSeu Sindicato vai custa: " + sindicato + "R$"
                + "\nSeu Desconto no geral vai ser: " + descontos + "R$" 
                + "\nSeu Salário Líquido é: " + salarioLiquido);
    }
}
