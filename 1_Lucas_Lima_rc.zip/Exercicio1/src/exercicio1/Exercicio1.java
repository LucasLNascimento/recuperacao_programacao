package exercicio1;

import java.io.DataInputStream;
import java.io.IOException;

public class Exercicio1 {

    public static void main(String[] args) throws IOException {
        String ajuda = "";
        int idade = 0, ano = 365, mesDia = 30, mes = 0, dia = 0;
        int diasVividos = 0;
        DataInputStream dado = new DataInputStream(System.in);
        
        System.out.println("Informe sua idade: ");
        ajuda = dado.readLine();
        idade = Integer.parseInt(ajuda);
        
        System.out.println("Informe o mês que você nasceu: ");
        ajuda = dado.readLine();
        mes = Integer.parseInt(ajuda);
        
        System.out.println("Agora, informe o dia que você nasceu: ");
        ajuda = dado.readLine();
        dia = Integer.parseInt(ajuda);
        
        diasVividos = (idade * ano) + (mesDia * mes) + dia;
        
        System.out.println(idade + " anos, " + mes + " meses e " + 
                dia + " dias = " + diasVividos + " dias");
    }
}
