package pkg3_lucas_lima_rc;

import java.io.IOException;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) throws IOException {
        int numero1 = 0, numero2 = 0, entrada = 0;
        
        numero1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o primeiro número: "));
        numero2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o segundo número: "));
        
        while (entrada != 2 & entrada != 7){
            for (int i = 0; i < numero1; i++){
                JOptionPane.showMessageDialog(null, "O resultado do primeiro número: " + (numero1 + i));
            }
            
            for (int o = 0; o <= numero2; o--){
                JOptionPane.showMessageDialog(null, "O resultado do segundo número: " + (numero2 + o));
            }
        }
    }
}
