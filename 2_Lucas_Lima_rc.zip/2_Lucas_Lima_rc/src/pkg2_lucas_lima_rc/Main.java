package pkg2_lucas_lima_rc;

import java.io.DataInputStream;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream (System.in);
        int opcao = 0, qtdExpresso = 0, qtdCapuccino = 0, qtdLeiteCafe = 0, qtdVendas = 0;
        float cafeExpresso = 0.0f, cafeCapuccino = 0.0f, leiteCafe = 0.0f, valorTotal = 0.0f;
        
        System.out.println("-------------- BEM VINDO --------------");
        System.out.println("Cardápio: " + 
                "\nCafé Expresso | R$ 0,75 " +
                "\nCafé Capuccino | R$ 1,00 " +
                "\nLeite Com Café | R$ 1,25 ");
        
        System.out.println("Opção: ");
        
        opcao = Integer.parseInt(dado.readLine());
        
        while (opcao != 4){
            System.out.println("Digite 1 para Café Expresso | R$ 0,75 " + 
                    "\nDigite 2 para Café Capuccino | R$ 1,00 " +
                    "\nDigite 3 para Leite Com Café | R$ 1,25 " +
                    "\nDigite 4 para Totalizar Vendas");
            
            opcao = Integer.parseInt(dado.readLine());
        
        switch (opcao){
            case 1:
                cafeExpresso += 0.75f;
                qtdExpresso += 1;
                break;
                
            case 2:
                cafeCapuccino += 1.00f;
                qtdCapuccino += 1;
                break;
                
            case 3:
                leiteCafe += 1.25f;
                qtdLeiteCafe += 1;
                break;
                
            case 4:
                break;
                
            default:
                System.err.println("Digite uma valor Inválido!");
        }
        
        qtdVendas = qtdExpresso + qtdCapuccino + qtdLeiteCafe;
        valorTotal = cafeExpresso + cafeCapuccino + leiteCafe;
        
        System.out.println("Unidades vendidas de Café Expresso " + qtdExpresso + " | Valor Total: " + cafeExpresso 
            + "\nUnidades vendidas de Café Capuccino " + qtdCapuccino + " | Valor Total: " + cafeCapuccino 
            + "\nUnidades vendidas de Leite com Café " + qtdLeiteCafe + " | Valor Total: " + leiteCafe 
            + "\nQuantidade Total: " + qtdVendas + " | Valor Total: " + valorTotal);
        }
    }
}