package pkg8_lucas_lima_rc;

import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream (System.in);
        String nome = "", categoria = "";
        float peso = 0.0f;
        
        System.out.println("Informe seu nome: ");
        nome = dado.readLine();
        
        System.out.println("Informe seu peso: ");
        peso = Float.parseFloat(dado.readLine());
        
        FileWriter arq = new FileWriter ("C:\\Users\\aluno\\Desktop\\Cadastro do UFC.txt");
        PrintWriter gravarArq = new PrintWriter (arq);
        
        if (peso < 65){
            categoria = "Pena";
        }else if (peso >= 65 & peso < 72){
            categoria = "Leve";
        }else if (peso >= 72 & peso < 79){
            categoria = "Ligeiro";
        }else if (peso >= 79 & peso < 86){
            categoria = "Meio médio";
        }else if (peso >= 86 & peso < 93){
            categoria = "Médio";
        }else if (peso >= 93 & peso < 100){
            categoria = "Meio pesado";
        }else if (peso >= 100){
            categoria = "Pesado";
        }
        
        
        gravarArq.println("--------------------------------");
        
        gravarArq.println("Nome Fornecido: " + nome);
        gravarArq.println("Peso Fornecido: " + peso);
        
        gravarArq.println("O lutador " + nome + " pesa " + peso + 
                "kg e se enquadra na categoria " + categoria);
        
         gravarArq.println("--------------------------------");
         
         arq.close();
    }
}
