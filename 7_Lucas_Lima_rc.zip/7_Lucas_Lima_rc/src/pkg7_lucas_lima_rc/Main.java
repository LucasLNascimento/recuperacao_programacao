package pkg7_lucas_lima_rc;

import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream (System.in);
        int numero = 0, resultado = 0;
        
        System.out.println("Informe um número: ");
        numero = Integer.parseInt(dado.readLine());
        
        FileWriter arq = new FileWriter ("C:\\Users\\aluno\\Desktop\\Tabuada de " + numero + ".txt");
        PrintWriter gravarArq = new PrintWriter (arq);
        
        gravarArq.println("--------------------------------");
        
        for (int i = 1; i <= 10; i++){
            
            resultado = numero * i;
            
            gravarArq.println(numero + " x " + i + " = " + resultado);
        }
        
        gravarArq.println("--------------------------------");
        arq.close();
    }
}
