package pkg4_lucas_lima_rc;

import java.io.DataInputStream;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream (System.in);
        String meses = "";
        int mes = 0;
        
        System.out.println("Digite o valor do mês: ");
        mes = Integer.parseInt(dado.readLine());
        
        switch(mes){
            case 1:
                meses = "Janeiro";
                break;
                
            case 2:
                meses = "Fevereiro";
                break;
                
            case 3:
                meses = "Março";
                break;
                
            case 4:
                meses = "Abril";
                break;
                
            case 5:
                meses = "Maio";
                break;
                
            case 6:
                meses = "Junho";
                break;
                
            case 7:
                meses = "Julho";
                break;
                
            case 8:
                meses = "Agosto";
                break;
                
            case 9:
                meses = "Setembro";
                break;
                
            case 10:
                meses = "Outubro";
                break;
                
            case 11:
                meses = "Novembro";
                break;
                
            case 12:
                meses = "Dezembro";
                break;
                
            default:
                System.err.print("Inválido!");
        }
        
        System.out.println("O mês que você escolheu foi " + meses);
    }
    
}
